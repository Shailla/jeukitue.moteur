#ifndef _MK_HAVE_STRTOLD
#define _MK_HAVE_STRTOLD "yes"
#endif
