#ifndef _MK_HAVE_UNISTD_H
#define _MK_HAVE_UNISTD_H "yes"
#endif
