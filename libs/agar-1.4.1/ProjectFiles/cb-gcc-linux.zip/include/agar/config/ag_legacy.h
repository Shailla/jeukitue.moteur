#ifndef AG_LEGACY
#define AG_LEGACY "yes"
#endif
