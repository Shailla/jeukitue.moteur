#ifndef ENABLE_GUI
#define ENABLE_GUI "yes"
#endif
