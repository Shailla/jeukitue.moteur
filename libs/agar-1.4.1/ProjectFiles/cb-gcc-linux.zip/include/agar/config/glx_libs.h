#ifndef GLX_LIBS
#define GLX_LIBS "-lX11 -lGL"
#endif
