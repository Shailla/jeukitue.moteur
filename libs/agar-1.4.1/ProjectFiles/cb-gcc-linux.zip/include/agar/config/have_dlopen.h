#ifndef HAVE_DLOPEN
#define HAVE_DLOPEN "yes"
#endif
