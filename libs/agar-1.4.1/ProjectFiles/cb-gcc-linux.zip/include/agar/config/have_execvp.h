#ifndef HAVE_EXECVP
#define HAVE_EXECVP "yes"
#endif
