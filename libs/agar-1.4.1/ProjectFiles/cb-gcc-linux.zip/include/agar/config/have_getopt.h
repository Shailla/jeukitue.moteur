#ifndef HAVE_GETOPT
#define HAVE_GETOPT "yes"
#endif
