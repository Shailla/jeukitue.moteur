#ifndef HAVE_GLX
#define HAVE_GLX "yes"
#endif
