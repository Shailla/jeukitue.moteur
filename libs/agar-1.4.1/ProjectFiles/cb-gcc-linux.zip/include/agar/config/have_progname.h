#ifndef HAVE_PROGNAME
#define HAVE_PROGNAME "yes"
#endif
