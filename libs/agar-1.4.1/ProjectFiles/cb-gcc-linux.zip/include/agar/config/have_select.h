#ifndef HAVE_SELECT
#define HAVE_SELECT "yes"
#endif
