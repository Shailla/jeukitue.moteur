#ifndef HAVE_STRSEP
#define HAVE_STRSEP "yes"
#endif
