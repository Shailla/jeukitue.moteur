#ifndef HAVE_VASPRINTF
#define HAVE_VASPRINTF "yes"
#endif
