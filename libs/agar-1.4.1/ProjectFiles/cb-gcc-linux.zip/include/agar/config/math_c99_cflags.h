#ifndef MATH_C99_CFLAGS
#define MATH_C99_CFLAGS ""
#endif
