#ifndef MATH_C99_LIBS
#define MATH_C99_LIBS "-lm"
#endif
