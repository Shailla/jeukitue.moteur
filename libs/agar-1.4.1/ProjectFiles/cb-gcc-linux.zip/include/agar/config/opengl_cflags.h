#ifndef OPENGL_CFLAGS
#define OPENGL_CFLAGS "-I/usr/X11R6/include"
#endif
