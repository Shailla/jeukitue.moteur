#ifndef PNG_CFLAGS
#define PNG_CFLAGS "-I/usr/include/libpng12 -I/usr/include -I/usr/local/include/libpng12 -I/usr/local/include -I/usr/X11R6/include -D_GNU_SOURCE=1 -D_REENTRANT"
#endif
