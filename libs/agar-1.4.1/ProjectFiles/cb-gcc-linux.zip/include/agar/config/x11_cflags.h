#ifndef X11_CFLAGS
#define X11_CFLAGS "-I/usr/X11R6/include"
#endif
