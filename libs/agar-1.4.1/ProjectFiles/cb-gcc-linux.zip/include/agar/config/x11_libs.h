#ifndef X11_LIBS
#define X11_LIBS "-L/usr/X11R6/lib -lX11"
#endif
