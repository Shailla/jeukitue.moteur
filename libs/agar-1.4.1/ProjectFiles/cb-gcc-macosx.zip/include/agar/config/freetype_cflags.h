#ifndef FREETYPE_CFLAGS
#define FREETYPE_CFLAGS "-I/usr/include/freetype2 -I/usr/local/include/freetype2 -I/usr/local/include -I/usr/X11R6/include/freetype2 -I/usr/X11R6/include"
#endif
