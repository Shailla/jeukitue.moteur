#ifndef FREETYPE_LIBS
#define FREETYPE_LIBS "-L/usr/local/lib -Wl,--rpath --Wl,/usr/local/lib -L/usr/X11R6/lib -Wl,--rpath --Wl,/usr/X11R6/lib -lfreetype -lz"
#endif
