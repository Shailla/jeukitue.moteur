#ifndef GLX_CFLAGS
#define GLX_CFLAGS "-I/usr/X11R6/include"
#endif
