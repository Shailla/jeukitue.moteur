#undef HAVE_MATH
