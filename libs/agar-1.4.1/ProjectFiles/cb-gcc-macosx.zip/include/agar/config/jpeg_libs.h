#ifndef JPEG_LIBS
#define JPEG_LIBS ""
#endif
