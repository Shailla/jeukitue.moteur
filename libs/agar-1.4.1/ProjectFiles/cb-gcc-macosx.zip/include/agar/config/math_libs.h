#ifndef MATH_LIBS
#define MATH_LIBS ""
#endif
