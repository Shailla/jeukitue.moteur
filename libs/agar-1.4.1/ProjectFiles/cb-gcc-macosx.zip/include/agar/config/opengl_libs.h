#ifndef OPENGL_LIBS
#define OPENGL_LIBS "-lGL"
#endif
