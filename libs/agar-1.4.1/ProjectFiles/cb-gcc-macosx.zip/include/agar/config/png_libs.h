#ifndef PNG_LIBS
#define PNG_LIBS "-lpng12 -lpthread"
#endif
