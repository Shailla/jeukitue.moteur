#ifndef SDL_CFLAGS
#define SDL_CFLAGS "-I/usr/include/SDL -I/usr/include -I/usr/local/include/SDL -I/usr/local/include -I/usr/X11R6/include/SDL -I/usr/X11R6/include -D_GNU_SOURCE=1 -D_REENTRANT"
#endif
