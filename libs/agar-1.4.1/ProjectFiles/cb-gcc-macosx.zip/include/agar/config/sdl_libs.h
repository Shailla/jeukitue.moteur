#ifndef SDL_LIBS
#define SDL_LIBS "-lSDL -lpthread"
#endif
