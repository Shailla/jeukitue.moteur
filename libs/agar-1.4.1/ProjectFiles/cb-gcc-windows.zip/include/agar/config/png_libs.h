#undef PNG_LIBS
