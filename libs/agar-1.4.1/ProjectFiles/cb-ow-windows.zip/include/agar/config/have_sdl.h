#ifndef HAVE_SDL
#define HAVE_SDL "yes"
#endif
