#ifndef HAVE_WGL
#define HAVE_WGL "yes"
#endif
