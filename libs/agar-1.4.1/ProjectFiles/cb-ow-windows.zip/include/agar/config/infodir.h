#ifndef INFODIR
#define INFODIR "/usr/local/share/info"
#endif
