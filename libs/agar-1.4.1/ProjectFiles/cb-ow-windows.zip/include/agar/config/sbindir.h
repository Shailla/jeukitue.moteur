#ifndef SBINDIR
#define SBINDIR "/usr/local/sbin"
#endif
