#ifndef LIBEXECDIR
#define LIBEXECDIR "/usr/local/libexec"
#endif
