#ifndef OPENGL_CFLAGS
#define OPENGL_CFLAGS ""
#endif
