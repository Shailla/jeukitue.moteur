#undef PNG_CFLAGS
