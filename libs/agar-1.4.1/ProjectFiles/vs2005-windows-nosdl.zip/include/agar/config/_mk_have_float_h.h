#undef _MK_HAVE_FLOAT_H
