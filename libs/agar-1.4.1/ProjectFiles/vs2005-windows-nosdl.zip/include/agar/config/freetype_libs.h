#ifndef FREETYPE_LIBS
#define FREETYPE_LIBS "freetype6"
#endif
