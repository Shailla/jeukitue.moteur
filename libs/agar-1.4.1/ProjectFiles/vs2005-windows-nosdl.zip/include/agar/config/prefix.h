#ifndef PREFIX
#define PREFIX "/usr/local"
#endif
