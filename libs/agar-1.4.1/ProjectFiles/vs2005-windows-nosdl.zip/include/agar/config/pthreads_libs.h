#ifndef PTHREADS_LIBS
#define PTHREADS_LIBS "pthreadVC2"
#endif
