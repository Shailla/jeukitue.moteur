#ifndef CLOCK_LIBS
#define CLOCK_LIBS "-lwinmm"
#endif
