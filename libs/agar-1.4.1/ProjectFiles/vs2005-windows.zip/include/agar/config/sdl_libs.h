#ifndef SDL_LIBS
#define SDL_LIBS "SDL SDLmain"
#endif
