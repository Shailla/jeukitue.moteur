#undef _MK_BIG_ENDIAN
