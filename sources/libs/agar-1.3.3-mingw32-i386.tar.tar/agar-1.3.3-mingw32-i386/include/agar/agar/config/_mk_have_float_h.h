#ifndef _MK_HAVE_FLOAT_H
#define _MK_HAVE_FLOAT_H "yes"
#endif
