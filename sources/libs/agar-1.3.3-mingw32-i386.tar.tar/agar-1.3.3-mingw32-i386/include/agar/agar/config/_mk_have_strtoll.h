#ifndef _MK_HAVE_STRTOLL
#define _MK_HAVE_STRTOLL "yes"
#endif
