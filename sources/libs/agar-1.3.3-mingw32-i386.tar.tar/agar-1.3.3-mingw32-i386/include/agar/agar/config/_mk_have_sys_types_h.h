#ifndef _MK_HAVE_SYS_TYPES_H
#define _MK_HAVE_SYS_TYPES_H "yes"
#endif
