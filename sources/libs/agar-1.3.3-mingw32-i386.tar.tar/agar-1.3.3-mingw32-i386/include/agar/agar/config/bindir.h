#ifndef BINDIR
#define BINDIR "/tmp/pkg-agar-1.3.3-mingw32-i386/agar-1.3.3-mingw32-i386/bin"
#endif /* BINDIR */
