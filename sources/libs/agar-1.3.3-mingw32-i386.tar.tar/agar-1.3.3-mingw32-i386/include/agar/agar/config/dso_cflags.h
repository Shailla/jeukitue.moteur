#ifndef DSO_CFLAGS
#define DSO_CFLAGS ""
#endif
