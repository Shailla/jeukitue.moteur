#ifndef DSO_LIBS
#define DSO_LIBS ""
#endif
