#ifndef EXECSUFFIX
#define EXECSUFFIX ".exe"
#endif /* EXECSUFFIX */
