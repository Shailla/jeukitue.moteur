#ifndef FREE_NULL_IS_A_NOOP
#define FREE_NULL_IS_A_NOOP "yes"
#endif
