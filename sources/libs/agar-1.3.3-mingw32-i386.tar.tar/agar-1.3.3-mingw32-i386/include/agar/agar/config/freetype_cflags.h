#ifndef FREETYPE_CFLAGS
#define FREETYPE_CFLAGS "-I/usr/local/include/freetype2 -I/usr/local/include"
#endif
