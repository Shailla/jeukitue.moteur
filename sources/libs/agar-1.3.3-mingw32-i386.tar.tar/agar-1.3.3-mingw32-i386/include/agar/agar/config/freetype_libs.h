#ifndef FREETYPE_LIBS
#define FREETYPE_LIBS "-L/usr/local/lib -L/usr/local/lib -lfreetype"
#endif
