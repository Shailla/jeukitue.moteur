#ifndef HAVE_CYGWIN
#define HAVE_CYGWIN "yes"
#endif
