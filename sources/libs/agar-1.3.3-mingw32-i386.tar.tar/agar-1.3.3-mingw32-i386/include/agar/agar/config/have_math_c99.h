#ifndef HAVE_MATH_C99
#define HAVE_MATH_C99 "yes"
#endif
