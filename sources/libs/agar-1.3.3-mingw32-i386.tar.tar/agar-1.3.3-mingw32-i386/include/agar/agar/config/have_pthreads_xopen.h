#ifndef HAVE_PTHREADS_XOPEN
#define HAVE_PTHREADS_XOPEN "yes"
#endif
