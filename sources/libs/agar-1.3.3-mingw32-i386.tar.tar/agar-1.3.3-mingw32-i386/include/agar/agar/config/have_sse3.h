#undef HAVE_SSE3
