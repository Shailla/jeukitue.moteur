#ifndef INCLDIR
#define INCLDIR "/tmp/pkg-agar-1.3.3-mingw32-i386/agar-1.3.3-mingw32-i386/include/agar"
#endif
