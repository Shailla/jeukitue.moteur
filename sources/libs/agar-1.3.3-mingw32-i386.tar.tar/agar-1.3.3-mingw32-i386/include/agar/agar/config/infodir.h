#ifndef INFODIR
#define INFODIR "/tmp/pkg-agar-1.3.3-mingw32-i386/agar-1.3.3-mingw32-i386/share/info"
#endif /* INFODIR */
