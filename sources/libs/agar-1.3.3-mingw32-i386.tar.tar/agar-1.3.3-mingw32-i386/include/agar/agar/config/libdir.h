#ifndef LIBDIR
#define LIBDIR "/tmp/pkg-agar-1.3.3-mingw32-i386/agar-1.3.3-mingw32-i386/lib"
#endif /* LIBDIR */
