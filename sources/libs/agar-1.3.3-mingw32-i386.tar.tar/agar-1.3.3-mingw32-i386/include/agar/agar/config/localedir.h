#ifndef LOCALEDIR
#define LOCALEDIR "/tmp/pkg-agar-1.3.3-mingw32-i386/agar-1.3.3-mingw32-i386/share/agar/locale"
#endif
