#ifndef MANDIR
#define MANDIR "/tmp/pkg-agar-1.3.3-mingw32-i386/agar-1.3.3-mingw32-i386/share/man"
#endif /* MANDIR */
