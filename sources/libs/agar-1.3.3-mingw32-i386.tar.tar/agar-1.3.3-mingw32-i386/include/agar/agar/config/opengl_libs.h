#ifndef OPENGL_LIBS
#define OPENGL_LIBS " -lopengl32"
#endif
