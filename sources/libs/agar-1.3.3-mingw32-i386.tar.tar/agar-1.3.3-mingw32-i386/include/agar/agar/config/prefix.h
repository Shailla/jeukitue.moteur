#ifndef PREFIX
#define PREFIX "/tmp/pkg-agar-1.3.3-mingw32-i386/agar-1.3.3-mingw32-i386"
#endif /* PREFIX */
