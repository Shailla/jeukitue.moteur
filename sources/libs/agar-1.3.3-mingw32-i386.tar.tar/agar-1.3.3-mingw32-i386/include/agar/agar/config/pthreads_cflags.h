#ifndef PTHREADS_CFLAGS
#define PTHREADS_CFLAGS "-I/usr/local/include"
#endif
