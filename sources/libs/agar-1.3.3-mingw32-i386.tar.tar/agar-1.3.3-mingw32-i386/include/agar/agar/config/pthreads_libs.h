#ifndef PTHREADS_LIBS
#define PTHREADS_LIBS "-L/usr/local/lib -lpthreadGCE2"
#endif
