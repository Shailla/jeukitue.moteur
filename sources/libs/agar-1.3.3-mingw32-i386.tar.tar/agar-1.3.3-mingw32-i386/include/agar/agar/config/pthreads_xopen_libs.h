#ifndef PTHREADS_XOPEN_LIBS
#define PTHREADS_XOPEN_LIBS "-L/usr/local/lib -lpthreadGCE2"
#endif
