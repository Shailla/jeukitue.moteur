#ifndef SDL_CFLAGS
#define SDL_CFLAGS "-I/usr/local/include/SDL -D_GNU_SOURCE=1 -Dmain=SDL_main"
#endif
