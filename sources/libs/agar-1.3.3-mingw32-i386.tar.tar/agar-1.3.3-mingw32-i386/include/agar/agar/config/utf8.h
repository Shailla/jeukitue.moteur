#ifndef UTF8
#define UTF8 "yes"
#endif
