#ifndef VIEW_16BPP
#define VIEW_16BPP "yes"
#endif
