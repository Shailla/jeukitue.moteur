#ifndef VIEW_24BPP
#define VIEW_24BPP "yes"
#endif
