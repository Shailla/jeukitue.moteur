#ifndef VIEW_32BPP
#define VIEW_32BPP "yes"
#endif
