#ifndef VIEW_8BPP
#define VIEW_8BPP "yes"
#endif
