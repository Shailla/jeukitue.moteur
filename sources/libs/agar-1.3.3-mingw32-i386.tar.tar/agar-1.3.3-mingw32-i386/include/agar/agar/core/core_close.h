/*	Public domain	*/

#ifdef _AGAR_DEBUG_
# undef _AGAR_DEBUG_
# undef DEBUG
#endif
#ifdef _AGAR_LOCKDEBUG_
# undef _AGAR_LOCKDEBUG_
# undef LOCKDEBUG
#endif
#ifdef _AGAR_THREADS_
# undef _AGAR_THREADS_
# undef THREADS
#endif
#ifdef _AGAR_THREADS_
# undef _AGAR_THREADS_
# undef THREADS
#endif
#ifdef _AGAR_HAVE_SYS_TYPES_H_
# undef _AGAR_HAVE_SYS_TYPES_H_
# undef _MK_HAVE_SYS_TYPES_H
#endif
#ifdef _AGAR_HAVE_64BIT_H_
# undef _AGAR_HAVE_64BIT_H_
# undef HAVE_64BIT
#endif
#ifdef _AGAR_HAVE_LONG_DOUBLE_H_
# undef _AGAR_HAVE_LONG_DOUBLE_H_
# undef HAVE_LONG_DOUBLE
#endif
#ifdef _AGAR_HAVE_STDLIB_H_
# undef _AGAR_HAVE_STDLIB_H_
# undef _MK_HAVE_STDLIB_H
#endif
#ifdef _AGAR_HAVE_UNISTD_H_
# undef _AGAR_HAVE_UNISTD_H_
# undef _MK_HAVE_UNISTD_H
#endif
#ifdef _AGAR_HAVE_UNSIGNED_TYPEDEFS_
# undef _AGAR_HAVE_UNSIGNED_TYPEDEFS_
# undef _MK_HAVE_UNSIGNED_TYPEDEFS
#endif
