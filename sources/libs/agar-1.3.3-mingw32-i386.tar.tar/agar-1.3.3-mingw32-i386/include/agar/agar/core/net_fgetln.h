/*	Public domain	*/

#include <agar/core/begin.h>
/* Begin generated block */
__BEGIN_DECLS
extern DECLSPEC char *NS_Fgetln(FILE *, size_t *);
__END_DECLS
/* Close generated block */
#include <agar/core/close.h>

