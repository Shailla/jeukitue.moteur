/*	Public domain	*/

#include <agar/gui/begin.h>
/* Begin generated block */
__BEGIN_DECLS
extern DECLSPEC Uint32 AG_ReadColor(AG_DataSource *, SDL_PixelFormat *);
extern DECLSPEC void AG_WriteColor(AG_DataSource *, SDL_PixelFormat *, Uint32);
__END_DECLS
/* Close generated block */
#include <agar/gui/close.h>
